declare module '*.bin';
// declare module '!./zbar.wasm' {
//   const content: string;
//   export default content;
// }
