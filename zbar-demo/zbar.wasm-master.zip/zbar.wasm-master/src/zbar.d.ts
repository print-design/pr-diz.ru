import ZBarInstance from './ZBarInstance';
declare const instantiate: (importObj: any) => Promise<ZBarInstance>;
export default instantiate;
